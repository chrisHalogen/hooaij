<?php

/**
 * Template Name: Product Tachoscope Page
 */
get_header();

// Fetch all active tachoscope products from DB
$products = hooaij_get_products_by_type('tachoscope');
$rate      = hooaij_get_exchange_rate();

// Build JS product map grouped by SKU prefix (category)
$category_map = [];
$prefix_map = [
    'B'    => [ 'label' => 'Bicycle',      'icon' => 'fas fa-bicycle' ],
    'T'    => [ 'label' => 'Tricycle',     'icon' => 'fas fa-motorcycle' ],
    'MB'   => [ 'label' => 'Motor Bike',   'icon' => 'fas fa-motorcycle' ],
    'C'    => [ 'label' => 'Car',          'icon' => 'fas fa-car' ],
    'BUTR' => [ 'label' => 'Bus & Truck',  'icon' => 'fas fa-truck-moving' ],
    'H'    => [ 'label' => 'Handheld',     'icon' => 'fas fa-hand-holding' ],
];

foreach ($products as $prod) {
    $sku_parts = explode('-', $prod->sku, 2);
    $prefix = $sku_parts[0];
    // BUTR prefix has a hyphen within, so handle specially
    if (strpos($prod->sku, 'BUTR-') === 0) {
        $prefix = 'BUTR';
    }
    if (!isset($category_map[$prefix])) {
        $category_map[$prefix] = [];
    }
    $p_usd = hooaij_ngn_to_usd($prod->price_ngn);
    $features_arr = is_string($prod->features) ? json_decode($prod->features, true) : ($prod->features ?? []);
    $category_map[$prefix][] = [
        'sku'        => $prod->sku,
        'name'       => $prod->name,
        'price_ngn'  => (float) $prod->price_ngn,
        'price_usd'  => round($p_usd, 2),
        'features'   => is_array($features_arr) ? $features_arr : [],
        'length_cm'  => $prod->length_cm ?? null,
        'width_cm'   => $prod->width_cm  ?? null,
        'height_cm'  => $prod->height_cm ?? null,
        'weight_kg'  => $prod->weight_kg ?? null,
    ];
}

$products_json = wp_json_encode($category_map);
$rate_json     = wp_json_encode((float) $rate);
?>

<!-- Product Hero Section -->
<section class="page-hero">
    <div class="container animate-up">
        <h1>Tachoscope Device</h1>
        <p>A professional-grade digital speed measuring device engineered for Engineers, Technologists and Technicians.</p>
    </div>
</section>

<!-- Product Details -->
<section class="section">
    <div class="container">
        <div class="product-layout animate-up">

            <!-- Description Area -->
            <div class="product-details">
                <img src="https://hooaij.com/wp-content/uploads/2026/03/tach.png" alt="Tachoscope Device"
                    style="width:100%; border-radius:var(--border-radius); margin-bottom:30px;">

                <span class="section-subtitle">Overview</span>
                <h2 class="section-title" style="font-size:2rem; margin-bottom:20px;">Description.</h2>

                <p class="intro-text-large" style="margin-bottom:30px;">The H-tachoscope is a special digital speed
                    measuring device designed with high esthetic and ergonomic features — meant for Engineers,
                    Technologists and Technicians. It helps to showcase your profession with precision and style.</p>

                <p>Designed with precision in mind, the Tachoscope offers unparalleled accuracy. Built using advanced
                    technology components that ensure longevity and reliable readings in diverse industrial or
                    professional environments.</p>

                <!-- Dynamic features (update when variant changes) -->
                <h3 style="margin-top:40px; margin-bottom:15px;">Key Benefits</h3>
                <ul id="tachoscope-features-list" style="list-style-type:none; margin-bottom: 25px;">
                    <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:var(--primary); margin-right:10px;"></i> High Esthetic Design</li>
                    <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:var(--primary); margin-right:10px;"></i> Ergonomic Handling</li>
                    <li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:var(--primary); margin-right:10px;"></i> Professional Grade Accuracy</li>
                </ul>

                <!-- Sister Company Notice -->
                <?php $sister_url = get_option('hooaij_company_website', ''); ?>
                <?php if ($sister_url): ?>
                    <div style="background: rgba(229, 120, 37, 0.05); border-left: 4px solid var(--primary); padding: 18px 22px; border-radius: 0 8px 8px 0; margin-top: 30px;">
                        <h4 style="margin: 0 0 10px; font-size: 1rem; color: var(--dark);">Professional Installation Services</h4>
                        <p style="margin: 0; font-size: 0.92rem; line-height: 1.5;">Need specialized installation for your Tachoscope? Visit our sister company for professional deployment services:
                           <a href="<?php echo esc_url($sister_url); ?>" target="_blank" style="color: var(--primary); font-weight: 700; text-decoration: underline;">Visit Website <i class="fas fa-external-link-alt" style="font-size: 0.8rem;"></i></a>
                        </p>
                    </div>
                <?php endif; ?>

                <!-- Physical Specs (shown when variant selected) -->
                <div id="tachoscope-specs" style="display:none; margin-top:30px;">
                    <h3 style="margin-bottom:15px;">Physical Specifications</h3>
                    <div class="specs-grid-display">
                        <div class="spec-cell"><span class="spec-val" id="spec-length">—</span><span class="spec-lbl">Length</span></div>
                        <div class="spec-cell"><span class="spec-val" id="spec-width">—</span><span class="spec-lbl">Width</span></div>
                        <div class="spec-cell"><span class="spec-val" id="spec-height">—</span><span class="spec-lbl">Height</span></div>
                        <div class="spec-cell"><span class="spec-val" id="spec-weight">—</span><span class="spec-lbl">Weight</span></div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="product-sidebar">
                <h3 style="font-size:1.5rem; margin-bottom:5px; font-family:'Source Sans Pro', sans-serif;">
                    Select Your Device
                </h3>
                <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:24px;">Step 1: Choose your vehicle type. Step 2: Pick a variant.</p>

                <?php if (empty($products)): ?>
                    <div style="background:var(--light); border:1px solid var(--border-color); border-radius:var(--border-radius); padding:20px; text-align:center; color:var(--text-muted);">
                        <i class="fas fa-box-open" style="font-size:2rem; margin-bottom:10px; display:block;"></i>
                        Products are being updated. Please check back shortly.
                    </div>
                <?php else: ?>

                <!-- ── Step 1: Vehicle Category Grid ── -->
                <div id="vehicle-category-grid" style="display:grid; grid-template-columns: repeat(3, 1fr); gap:10px; margin-bottom:24px;">
                    <?php foreach ($prefix_map as $prefix => $cat): ?>
                        <?php if (!isset($category_map[$prefix])) continue; ?>
                        <button class="vehicle-cat-btn" data-prefix="<?php echo esc_attr($prefix); ?>"
                            style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; padding:14px 8px; border:2px solid var(--border-color); border-radius:10px; background:var(--white); cursor:pointer; transition:all 0.2s ease; font-size:0.78rem; font-weight:600; color:var(--text-muted);">
                            <i class="<?php echo esc_attr($cat['icon']); ?>" style="font-size:1.5rem;"></i>
                            <?php echo esc_html($cat['label']); ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <!-- ── Step 2: Variant Cards ── -->
                <div id="variant-cards-container" style="display:none; margin-bottom:20px;">
                    <h5 id="variant-category-title" style="font-size:0.8rem; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:var(--text-muted); margin-bottom:12px;">Select a Variant</h5>
                    <div id="variant-cards-list" style="display:flex; flex-direction:column; gap:10px;"></div>
                </div>

                <!-- ── Price Display ── -->
                <div class="attribute-box" id="tachoscope-price-box" style="display:none;">
                    <div class="attribute-item">
                        <span class="attribute-key">Brand:</span>
                        <span class="attribute-value">Hooaij</span>
                    </div>
                    <div class="attribute-item">
                        <span class="attribute-key">Price:</span>
                        <span class="attribute-value fee">
                            <span id="tachoscope-price-display" style="font-size:1.4rem; color:var(--primary); font-weight:700;">—</span>
                        </span>
                    </div>
                    <div class="attribute-item" style="display:block; padding-top:0; border:none;">
                        <small id="tachoscope-ngn-equiv" style="color:var(--text-muted); font-size:0.8rem;"></small>
                    </div>
                </div>

                <!-- ── Action Box ── -->
                <div class="action-box product-order-section" id="tachoscope-action-box" style="display:none;">
                    <h4 style="margin-bottom:15px; font-size:1.1rem;">Place Your Order</h4>

                    <button id="tachoscope-order-btn" class="btn btn-primary btn-block"
                        style="font-size:1.05rem; padding:14px; justify-content:center; display:flex; align-items:center; gap:10px;">
                        Order Now <i class="fas fa-shopping-cart"></i>
                    </button>

                    <!-- Checkout Form (hidden by default) -->
                    <div id="tachoscope-checkout-wrapper" style="margin-top:20px; display:none;">
                        <?php
                        $first_product = reset($products);
                        if ($first_product) {
                            hooaij_render_checkout_form($first_product->sku);
                        }
                        ?>
                    </div>
                </div>

                <?php endif; // end if products ?>

                <p style="text-align:center; font-size:0.78rem; color:var(--text-muted); margin-top:12px;">
                    <i class="fas fa-lock" style="margin-right:4px;"></i> Secured by PayPal
                </p>

            </div><!-- /.product-sidebar -->

        </div><!-- /.product-layout -->
    </div>
</section>

<!-- ── Inline Styles for Category Grid ── -->
<style>
.vehicle-cat-btn.active {
    border-color: var(--primary) !important;
    color: var(--primary) !important;
    background: rgba(229,120,37,0.07) !important;
    box-shadow: 0 0 0 3px rgba(229,120,37,0.15);
}
.vehicle-cat-btn:hover:not(.active) {
    border-color: rgba(229,120,37,0.5) !important;
    color: var(--dark) !important;
    background: var(--light) !important;
}
.variant-card {
    border: 2px solid var(--border-color);
    border-radius: 10px;
    padding: 14px 16px;
    cursor: pointer;
    transition: all 0.2s ease;
    background: var(--white);
}
.variant-card:hover, .variant-card.selected {
    border-color: var(--primary);
    background: rgba(229,120,37,0.05);
}
.variant-card.selected {
    box-shadow: 0 0 0 3px rgba(229,120,37,0.15);
}
.variant-card-name {
    font-weight: 700;
    font-size: 0.92rem;
    color: var(--dark);
    margin-bottom: 4px;
}
.variant-card-price {
    font-size: 1rem;
    font-weight: 700;
    color: var(--primary);
}
.variant-card-dims {
    font-size: 0.75rem;
    color: var(--text-muted);
    margin-top: 4px;
}
</style>

<!-- ── Visual Selector JavaScript ── -->
<script>
(function() {
    var PRODUCTS = <?php echo $products_json; ?>;
    var RATE     = <?php echo $rate_json; ?>;
    var selectedSKU = null;

    // ── Helper: update sidebar specs & features
    function applyVariant(prod) {
        // Features
        var feats = prod.features || [];
        if (feats.length) {
            var html = feats.map(function(f) {
                return '<li style="margin-bottom:10px;"><i class="fas fa-check-circle" style="color:var(--primary); margin-right:10px;"></i>' + f + '</li>';
            }).join('');
            document.getElementById('tachoscope-features-list').innerHTML = html;
        }

        // Price
        document.getElementById('tachoscope-price-display').textContent = '$' + prod.price_usd.toFixed(2);
        document.getElementById('tachoscope-ngn-equiv').textContent = '≈ ₦' + Number(prod.price_ngn).toLocaleString() + ' @ ₦' + Number(RATE).toLocaleString() + '/$1';
        document.getElementById('tachoscope-price-box').style.display = '';

        // Specs
        if (prod.length_cm) {
            document.getElementById('tachoscope-specs').style.display = '';
            document.getElementById('spec-length').textContent = prod.length_cm + ' cm';
            document.getElementById('spec-width').textContent  = prod.width_cm  + ' cm';
            document.getElementById('spec-height').textContent = prod.height_cm + ' cm';
            document.getElementById('spec-weight').textContent = prod.weight_kg + ' kg';
        }

        // Update checkout form data attributes
        var $form = document.querySelector('.hooaij-checkout-form[data-type="tachoscope"]');
        if ($form) {
            $form.setAttribute('data-sku', prod.sku);
            $form.setAttribute('data-price-ngn', prod.price_ngn);
            $form.setAttribute('data-price-usd', prod.price_usd);
            var skuInput = $form.querySelector('.checkout-sku');
            if (skuInput) skuInput.value = prod.sku;
            // Re-init PayPal buttons via jQuery checkout.js
            if (window.jQuery) {
                var $jForm = jQuery($form);
                var newBtnId = 'paypal-button-container-' + prod.sku;
                $jForm.find('.paypal-btn-container').attr('id', newBtnId).empty();
                if (typeof initPayPalButtons === 'function') {
                    initPayPalButtons($jForm);
                }
            }
        }

        // Show action box
        document.getElementById('tachoscope-action-box').style.display = '';
        selectedSKU = prod.sku;
    }

    // ── Render variant cards for a category
    function renderVariantCards(prefix) {
        var variants = PRODUCTS[prefix] || [];
        var container = document.getElementById('variant-cards-list');
        var wrapper   = document.getElementById('variant-cards-container');
        var title     = document.getElementById('variant-category-title');

        if (!variants.length) {
            wrapper.style.display = 'none';
            return;
        }

        title.textContent = 'Choose a ' + prefix + ' variant:';
        container.innerHTML = '';

        variants.forEach(function(prod) {
            var card = document.createElement('div');
            card.className = 'variant-card';
            card.setAttribute('data-sku', prod.sku);

            var dims = '';
            if (prod.length_cm) {
                dims = prod.length_cm + ' × ' + prod.width_cm + ' × ' + prod.height_cm + ' cm | ' + prod.weight_kg + ' kg';
            }

            card.innerHTML =
                '<div class="variant-card-name">' + prod.name + '</div>' +
                '<div class="variant-card-price">$' + prod.price_usd.toFixed(2) + ' <small style="color:var(--text-muted); font-weight:400;">≈ ₦' + Number(prod.price_ngn).toLocaleString() + '</small></div>' +
                (dims ? '<div class="variant-card-dims">📐 ' + dims + '</div>' : '');

            card.addEventListener('click', function() {
                // Deselect all
                container.querySelectorAll('.variant-card').forEach(function(c) { c.classList.remove('selected'); });
                card.classList.add('selected');
                applyVariant(prod);

                // Smooth scroll to action box on mobile
                var actionBox = document.getElementById('tachoscope-action-box');
                if (actionBox && window.innerWidth < 992) {
                    actionBox.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });

            container.appendChild(card);
        });

        wrapper.style.display = '';
    }

    // ── Category button click handler
    document.querySelectorAll('.vehicle-cat-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var prefix = btn.getAttribute('data-prefix');

            // Toggle highlight
            document.querySelectorAll('.vehicle-cat-btn').forEach(function(b) { b.classList.remove('active'); });
            btn.classList.add('active');

            // Reset action box & price if switching categories
            document.getElementById('tachoscope-action-box').style.display = 'none';
            document.getElementById('tachoscope-price-box').style.display = 'none';

            renderVariantCards(prefix);
        });
    });

    // ── Wire "Order Now" => show/hide checkout form
    document.addEventListener('DOMContentLoaded', function() {
        var orderBtn = document.getElementById('tachoscope-order-btn');
        if (orderBtn) {
            orderBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (!selectedSKU) { return; }
                var wrapper = document.getElementById('tachoscope-checkout-wrapper');
                if (wrapper) {
                    if (wrapper.style.display === 'none' || wrapper.style.display === '') {
                        wrapper.style.display = 'block';
                        wrapper.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    } else {
                        wrapper.style.display = 'none';
                    }
                }
            });
        }
    });
})();
</script>

<?php get_footer(); ?>
