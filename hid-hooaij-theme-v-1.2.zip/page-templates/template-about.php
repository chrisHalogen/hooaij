<?php
/**
 * Template Name: About Page
 */
get_header();
?>

<!-- Page Hero -->
        <section class="page-hero">
            <div class="container animate-up">
                <h1>About Us</h1>
                <p>Delivering products and services at exquisite value.</p>
            </div>
        </section>

        <!-- Intro Section -->
        <section class="section">
            <div class="container">
                <div class="grid-2 animate-up">
                    <div>
                        <span class="section-subtitle">Our Story</span>
                        <h2 class="section-title">We Have Perfectly Tailored Solutions For Your Needs</h2>
                    </div>
                    <div>
                        <p class="intro-text-large">We are the mother company that houses all products made by our
                            sister companies and so we do not only provide the umbrella under which all our other
                            companies operates from we also provide the market where vendors can easily and customers
                            can easily assess all our products.</p>
                        <p>At Hooaij, we understand that every client’s needs are unique. That’s why our team provides
                            custom-designed solutions that combine innovation, safety, and performance. Whether it’s
                            home automation, citywide security systems, or performance evaluation tools, we tailor each
                            project to meet real-world challenges efficiently.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section -->
        <section class="section section-light">
            <div class="container">
                <div class="stats-grid animate-up">
                    <div class="stat-item">
                        <div class="stat-number">420<span style="font-size: 2rem;">+</span></div>
                        <div class="stat-title">Completed Projects</div>
                        <p style="margin-top: 15px; font-size: 0.9rem; color: var(--text-muted);">We have successfully
                            delivered a wide range of projects across sectors, reflecting our dedication to excellence
                            and client satisfaction.</p>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">100<span style="font-size: 2rem;">%</span></div>
                        <div class="stat-title">Satisfied Customers</div>
                        <p style="margin-top: 15px; font-size: 0.9rem; color: var(--text-muted);">Our clients trust us
                            for quality, reliability, and consistent after-sales support that ensures long-term value.
                        </p>
                    </div>
                    <div class="stat-item" style="border-bottom-color: var(--secondary);">
                        <div class="stat-number">2,648</div>
                        <div class="stat-title">Working Hours</div>
                        <p style="margin-top: 15px; font-size: 0.9rem; color: var(--text-muted);">Our commitment and
                            focus drive every hour spent on research, development, and service delivery.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Values Section -->
        <section class="section">
            <div class="container">
                <div class="grid-3 animate-up">
                    <div class="card">
                        <div class="icon-wrap"><i class="fas fa-users-cog"></i></div>
                        <h3>Effective Team Work</h3>
                        <p>We work collaboratively across multiple disciplines to deliver reliable, future-ready
                            solutions that exceed expectations.</p>
                    </div>
                    <div class="card">
                        <div class="icon-wrap" style="background: rgba(191, 148, 111, 0.1); color: var(--secondary);"><i
                                class="fas fa-medal"></i></div>
                        <h3>35 Years Experience</h3>
                        <p>Our leadership brings over three decades of combined experience in technology design,
                            installation, and systems development.</p>
                    </div>
                    <div class="card">
                        <div class="icon-wrap" style="background: rgba(18, 18, 18, 0.1); color: var(--dark);"><i
                                class="fas fa-industry"></i></div>
                        <h3>High Technology Factory</h3>
                        <p>We integrate cutting-edge technology in every solution we create—ensuring precision,
                            durability, and world-class performance.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="section section-light">
            <div class="container">
                <div class="text-center animate-up" style="margin-bottom: 50px;">
                    <span class="section-subtitle">Leadership</span>
                    <h2 class="section-title center">Meet Our Team</h2>
                </div>

                <div class="grid-2 animate-up"
                    style="align-items: start; background: var(--white); border-radius: var(--border-radius-lg); overflow: hidden; box-shadow: var(--shadow-md);">
                    <div
                        style="background: var(--primary); height: 100%; min-height: 400px; display: flex; align-items: center; justify-content: center; color: var(--white); padding: 40px;">
                        <div style="text-align: center;">
                            <img src="https://hooaij.com/wp-content/uploads/2026/03/IMG_1043-768x960-1.jpg"
                                alt="Dr. Engr. Omoregbee Henry O."
                                style="width: 200px; height: 200px; object-fit: cover; border-radius: 50%; border: 5px solid var(--white); margin: 0 auto 20px;">
                            <h2>Dr. Engr. Omoregbee Henry O.</h2>
                            <p style="font-size: 1.1rem; opacity: 0.9;">Co-Founder & CEO</p>
                        </div>
                    </div>
                    <div style="padding: 50px 40px;">
                        <span
                            style="color: var(--primary); font-weight: 600; text-transform: uppercase;">Biography</span>
                        <h3 style="font-size: 2rem; margin-bottom: 20px; font-family: 'Source Sans Pro', sans-serif;">
                            Visionary Leader in Tech & Engineering</h3>
                        <p>He is the founder and chief executive officer of Innerberg Consulting.</p>

                        <ul style="margin-top: 30px; line-height: 1.8;">
                            <li style="margin-bottom: 15px; display: flex; gap: 10px;">
                                <i class="fas fa-check-circle" style="color: var(--primary); margin-top: 5px;"></i>
                                He began his career as a Mechanical Engineer at the Federal Polytechnic Ado-Ekiti,
                                Nigeria.
                            </li>
                            <li style="margin-bottom: 15px; display: flex; gap: 10px;">
                                <i class="fas fa-check-circle" style="color: var(--primary); margin-top: 5px;"></i>
                                He advanced into Production Engineering at the University of Benin, Nigeria, a
                                discipline gaining ground in Africa.
                            </li>
                            <li style="margin-bottom: 15px; display: flex; gap: 10px;">
                                <i class="fas fa-check-circle" style="color: var(--primary); margin-top: 5px;"></i>
                                He earned his Master’s degree in Industrial and Production Engineering at the University
                                of Ibadan, Nigeria.
                            </li>
                            <li style="margin-bottom: 15px; display: flex; gap: 10px;">
                                <i class="fas fa-check-circle" style="color: var(--primary); margin-top: 5px;"></i>
                                He obtained a PhD in Engineering Mechanics from the University of Pretoria, South
                                Africa, specializing in vibration and artificial intelligence.
                            </li>
                        </ul>

                        <p
                            style="margin-top: 20px; font-style: italic; color: var(--text-color); border-left: 4px solid var(--secondary); padding-left: 20px;">
                            "Dr. Henry’s career reflects a lifelong commitment to applying engineering knowledge across
                            multiple disciplines, creating solutions that improve industries, communities, and lives."
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Our Clients -->
        <section class="section">
            <div class="container text-center animate-up">
                <span class="section-subtitle">Connections</span>
                <h2 class="section-title center">Our Clients</h2>
                <p class="intro-text-large" style="max-width: 800px; margin: 0 auto;">We proudly serve individuals,
                    organizations, and institutions that trust Hooaij for their smart technology needs. Our client base
                    includes companies in engineering, construction, security, education, and government sectors who
                    rely on us for efficient, technology-driven solutions.</p>
            </div>
        </section>

    <?php get_footer(); ?>